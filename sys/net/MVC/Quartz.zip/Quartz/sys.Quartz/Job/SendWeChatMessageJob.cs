﻿using System; 
using Quartz; 

namespace sys.Quartz
{
    public class SendWeChatMessageJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            //推送 
            NetLog.WriteTextLog(string.Format("推模板送消息到微信{0}", DateTime.Now)); 
            //SendWeChatMessage.SendPushMessage();

        }


    }
} 