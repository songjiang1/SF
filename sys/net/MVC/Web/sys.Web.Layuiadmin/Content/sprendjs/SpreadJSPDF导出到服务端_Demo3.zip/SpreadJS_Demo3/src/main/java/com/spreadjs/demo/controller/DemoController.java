package com.spreadjs.demo.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {
    
	@RequestMapping(value="/loadImport",method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> loadImport() throws IOException, ServletException{		
    	int result= 0;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
    	File importFile = new File("d:\\importExcel.xlsx");
    	try {
    		resultMap.put("importFile", importFile);
			resultMap.put("isSuccess", 1);
		} catch (Exception e) {
			resultMap.put("isSuccess", result);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		} 
    	return resultMap;
    }
	
	@RequestMapping(value = "/downLoad", method = RequestMethod.GET)
	@ResponseBody
	public void downLoad(HttpServletRequest request,
			HttpServletResponse response, Model model){
    	int size = 4096;
    	OutputStream os = null;
        File importFile = new File("d:\\test.xlsx");
        FileInputStream fis = null;
		try {
			fis = new FileInputStream(importFile);
			int len = 0;
			byte[] buf = new byte[size];
			os = response.getOutputStream();
			while((len=fis.read(buf))!=-1){
				os.write(buf, 0, len);
				os.flush();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
       
    }
 
    @RequestMapping(value="/saveExport",method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> saveExport(HttpServletRequest request) throws IOException, ServletException{		
    	int result= 0;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
    	MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
    	Map<String,MultipartFile> fileMap = multipartRequest.getFileMap();
    	MultipartFile file = fileMap.get("test.xlsx");
    	//���Խ��ϴ��ļ�ת����ָ��·����ģ�����������
    	File newfile = new File("d:\\testupload.xlsx");
    	try {
			file.transferTo(newfile);
			resultMap.put("isSuccess", 1);
		} catch (Exception e) {
			resultMap.put("isSuccess", result);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		} 
    	return resultMap;
    	/*Part part = request.getPart("test.xlsx");
    	part.write("d:\\testupload.xlsx");
    	request.getSession().getServletContext().getRealPath("");
    	return resultMap;*/
    }
    
    @RequestMapping("/index")
    public ModelAndView index(){
    	ModelAndView mav = new ModelAndView();
    	mav.setViewName("demo");
        return mav;
    }
}
	