var sheet;
var spread;
var updateRows = [];
var columnSetting = [];
$(document).ready(function () { 
	var tableNames = [];
	
	$.ajax({
		url: "getAllTables",
		datatype: "json",
		async:false,
		success: function (data) {
			if(data.isSuccess == 1){
				for(var i=0;i<data.resultData.length;i++){
					tableNames.push(data.resultData[i].table_name);
					$("#table_name").append("<option value='"+data.resultData[i].table_name+"'>"+data.resultData[i].table_name+"</option>");
				}
			}else{
				alert(data.errorMessage);
			}
			
		},
		error: function (ex) {
			alert(ex);
		}
	});
	
	spread = new GC.Spread.Sheets.Workbook(document.getElementById('ss'), { sheetCount: 1 });
	
	sheet = spread.getActiveSheet();
	
	selectChange();
	
	$("#table_name").change(function(){
		selectChange();
		
	});
	
	spread.bind(GC.Spread.Sheets.Events.CellChanged, function(e,args) {
		var dirtyRows = sheet.getDirtyRows();
		if(dirtyRows.length>0){
			updateData(dirtyRows);
		}
    });
});


function selectChange(){
	var selectedTableName = $("#table_name").find("option:selected").text();
	$.ajax({
		url: "getDataFromTableName",
		type:"post",
		data:{tableName:selectedTableName},
		datatype: "json",
		success: function (data) {
			//var json = JSON.parse(data);
			if(data.isSuccess == 1){
				spread.suspendPaint();
				sheet.clearPendingChanges();
				columnSetting = data.resultData.columnSetting;
				sheet.setDataSource(data.resultData.dataList);
				formatColumn(columnSetting);
				spread.resumePaint();
			}else{
				alert(data.errorMessage);
			}
		},
		error: function (ex) {
			alert(ex);
		}
	});
}

function addRow(){
	var rows = sheet.getRowCount();
    if (rows > 0) {
        sheet.addRows(rows, 1);
    }else{
    	sheet.addRows(0, 1);
    	var row = {};
    }
}

function deleteRow(){
	var sels = sheet.getSelections();
    var len = sels.length;
    if (len > 0) {
        var s = sels[0];
        sheet.deleteRows(s.row, s.rowCount);
    }
}

function formatColumn(columnSettings){
	for(var i=0;i<columnSettings.length;i++){
		var columnType = columnSettings[i].columnType;
		var column = sheet.getRange(-1,i,-1,1);
		switch(columnType){
			case 4: 
			case -5: 
			case -6: 
			case 5:
			case 16:
				column.formatter('0');
				break;
			case 6:
			case 8:
			case 2:
			case 3:
				column.formatter('0.00');
				break;
			case 91:
			case 93:
				column.formatter('yyyy/MM/dd hh:mm:ss');
				break;
			default:
				column.formatter(undefined);
		}
	}
}

function updateData(dirtyRows){
	var selectedTableName = $("#table_name").find("option:selected").text();
	//获取列名
	var columnName = [];
	var columnCount = sheet.getColumnCount();
	for(var i=0;i<columnCount;i++){
		columnName.push(sheet.getValue(0,i,GC.Spread.Sheets.SheetArea.colHeader));
	}
	var requestData = {};
	requestData.dirtyRows = dirtyRows;
	requestData.tableName = selectedTableName;
	requestData.columnName = columnName;
	$.ajax({
		url: "updateDataFromTableName",
		type:"post",
		dataType:"json",      
		contentType:"application/json",
		data:JSON.stringify(requestData),
		success: function (data) {
			if(data.isSuccess == 1){
				sheet.clearPendingChanges();
				selectChange();
			}else{
				alert(data.errorMessage);
				sheet.clearPendingChanges();
				selectChange();
			}
		},
		error: function (ex) {
			alert(ex);
		}
	});
}

function saveData(){
	//先删除再新增
	var selectedTableName = $("#table_name").find("option:selected").text();
	var insertRows = sheet.getInsertRows();
	var deleteRows = sheet.getDeletedRows();
	//获取列名
	var columnName = [];
	var columnCount = sheet.getColumnCount();
	for(var i=0;i<columnCount;i++){
		columnName.push(sheet.getValue(0,i,GC.Spread.Sheets.SheetArea.colHeader));
	}
	var requestData = {};
	requestData.insertRows = insertRows;
	requestData.deleteRows = deleteRows;
	requestData.tableName = selectedTableName;
	requestData.columnName = columnName;
	$.ajax({
		url: "saveDataFromTableName",
		type:"post",
		dataType:"json",      
		contentType:"application/json",
		data:JSON.stringify(requestData),
		success: function (data) {
			if(data.isSuccess == 1){
				sheet.clearPendingChanges();
				selectChange();
			}else{
				alert(data.errorMessage);
				sheet.clearPendingChanges();
				selectChange();
			}
		},
		error: function (ex) {
			alert(ex);
		}
	});
}

function exportData(){
	var selectedTableName = $("#table_name").find("option:selected").text();
	var fileName = "export_"+selectedTableName+".xlsx";
    var json = spread.toJSON({includeBindingSource: true});
    var excelIo = new GC.Spread.Excel.IO();
    // here is excel IO API   
    excelIo.save(json, function (blob) {
        saveAs(blob, fileName);
    }, function (e) {
    	alert(e);
    });
}


