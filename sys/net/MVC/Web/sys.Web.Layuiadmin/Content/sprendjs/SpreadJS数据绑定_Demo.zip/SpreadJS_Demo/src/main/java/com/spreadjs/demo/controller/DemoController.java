package com.spreadjs.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.spreadjs.demo.services.DemoService;

@Controller
public class DemoController {

	@Autowired
	private DemoService service;
	
    @RequestMapping("/getDataFromTableName")
    @ResponseBody
    public Map<String,Object> getDataFromTableName(String tableName){
    	Map<String, Object> dataMap = null;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			dataMap = service.getDataFromTableName(tableName);
		} catch (Exception e) {
			resultMap.put("isSuccess", 0);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		resultMap.put("isSuccess", 1);
		resultMap.put("resultData", dataMap);
    	return resultMap;
    }
    
    @RequestMapping("/getAllTables")
    @ResponseBody
    public Map<String,Object> getAllTables(){
    	List<Map<String, Object>> resultList = null;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			resultList = service.getAllTables();
		} catch (Exception e) {
			resultMap.put("isSuccess", 0);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		resultMap.put("isSuccess", 1);
		resultMap.put("resultData", resultList);
    	return resultMap;
    }
    
    @RequestMapping("/updateDataFromTableName")
    @ResponseBody
    public Map<String,Object> updateDataFromTableName(@RequestBody Map<String,Object> requestData){
    	int result = 0;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			result = service.updateDataFromTableName(requestData);
		} catch (Exception e) {
			resultMap.put("isSuccess", result);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		resultMap.put("isSuccess", result);
    	return resultMap;
    }
    
    @RequestMapping("/saveDataFromTableName")
    @ResponseBody
    public Map<String,Object> saveDataFromTableName(@RequestBody Map<String,Object> requestData){		
    	int result= 0;
    	Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			result = service.saveDataFromTableName(requestData);
			
		} catch (Exception e) {
			resultMap.put("isSuccess", result);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		resultMap.put("isSuccess", result);
    	return resultMap;
    }
    
    @RequestMapping("/index")
    public ModelAndView index(){
    	ModelAndView mav = new ModelAndView();
    	mav.setViewName("demo");
        return mav;
    }
}
	