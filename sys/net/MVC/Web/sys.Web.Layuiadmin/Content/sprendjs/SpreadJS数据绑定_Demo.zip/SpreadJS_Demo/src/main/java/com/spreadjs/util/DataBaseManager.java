package com.spreadjs.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value="classpath:resources.properties")
public class DataBaseManager {
	
	public Connection getConnection() throws IOException{
		InputStream in = this.getClass().getClassLoader().getResourceAsStream("resources.properties");
		Properties ps = new Properties();
		ps.load(in);
		in.close();
		String url = ps.get("url").toString();
		String name = ps.get("name").toString();
		String user = ps.get("user").toString();
		String password = ps.get("password").toString();
		Connection conn = null;
		try {
			Class.forName(name);
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return conn;
	}
	
	public void closeConnection(Connection conn) {
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void closePstmt(PreparedStatement pstmt) {
		if(pstmt!=null){
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}
