package com.spreadjs.demo.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.spreadjs.util.DataBaseManager;

@Service
public class DemoService {
	
	public Map<String,Object> getDataFromTableName(String tableName) throws Exception{
		Map<String,Object> dataMap = new HashMap<String,Object>();
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
		String sql = "select * from "+tableName;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = new DataBaseManager().getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			List<Map<String,Object>> columns = new ArrayList<Map<String,Object>>();
			for(int i=1;i<=rsmd.getColumnCount();i++){
				Map<String,Object> columnPerferences = new HashMap<String,Object>();
				columnPerferences.put("columnName", rsmd.getColumnName(i));
				columnPerferences.put("columnType", rsmd.getColumnType(i));
				columns.add(columnPerferences);
			}
			dataMap.put("columnSetting", columns);
			while(rs.next()){
				Map<String,Object> resultMap = new LinkedHashMap<String,Object>();
				for(int j=0;j<columns.size();j++){
					int columnType = Integer.parseInt(columns.get(j).get("columnType").toString());
					String columnName = columns.get(j).get("columnName").toString();
					if (Types.VARCHAR == columnType) {
						resultMap.put(columnName, rs.getObject(columnName)==null?null:rs.getString(columnName));
					} else if (Types.INTEGER == columnType) { 
						resultMap.put(columnName, rs.getObject(columnName)==null?null:rs.getInt(columnName)); 
					} else if (Types.SMALLINT == columnType) {
						resultMap.put(columnName, rs.getObject(columnName)==null?null:rs.getShort(columnName)); 
					} else {
						resultMap.put(columnName, rs.getObject(columnName)==null?null:rs.getString(columnName)); 
					}
				}
				listMap.add(resultMap);
			}
			dataMap.put("dataList", listMap);
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			new DataBaseManager().closeConnection(conn);
			new DataBaseManager().closePstmt(pstmt);
		}
		return dataMap;
	}

	public List<Map<String, Object>> getAllTables() throws Exception {
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
		String sql = "select table_name from information_schema.tables where table_schema='spreadjs' and table_type='base table'";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = new DataBaseManager().getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Map<String,Object> resultMap = new HashMap<String,Object>();
				resultMap.put("table_name", rs.getString("table_name"));
				listMap.add(resultMap);
			}
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			new DataBaseManager().closeConnection(conn);
			new DataBaseManager().closePstmt(pstmt);
		}
		return listMap;
	}
	
	

	public int updateDataFromTableName(Map<String, Object> requestData) throws Exception {
		List<Map<String,Object>> dirtyDatas = (List<Map<String,Object>>) requestData.get("dirtyRows");
		List<String> columnNames = (List<String>) requestData.get("columnName");
		String tableName = (String) requestData.get("tableName");
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = new DataBaseManager().getConnection();
			conn.setAutoCommit(false);
			String sql = null;
		

			if(dirtyDatas.size()>0){
				for(int i=0;i<dirtyDatas.size();i++){
					
					sql = "update "+tableName+" set ";
					for(int j=0;j<columnNames.size();j++){
						String columnName = columnNames.get(j);
						sql = sql+columnName+"=?,";
					}
					sql = sql.substring(0, sql.lastIndexOf(',')) + " where 1=1 ";
					for(int j=0;j<columnNames.size();j++){
						String columnName = columnNames.get(j);
						Map<String,Object> originalItem = (Map<String, Object>) dirtyDatas.get(i).get("originalItem");
						Object value = originalItem.get(columnName);
						if(value==null){
							sql = sql+ " and "+columnName+" is null";
						}else{
							sql = sql+ " and "+columnName+"=?";
						}
					}
					
					
					pstmt = conn.prepareStatement(sql);
					Map<String,Object> dirtyData = dirtyDatas.get(i);
					int index = 1;
					for(int j=0;j<columnNames.size()*2;j++){
						if(j<columnNames.size()){
							String columnName = columnNames.get(j);
							Map<String,Object> item = (Map<String, Object>) dirtyData.get("item");
							Object value = item.get(columnName);
							pstmt.setObject(index,value);
						}else{
							String columnName = columnNames.get(j-columnNames.size());
							Map<String,Object> originalItem = (Map<String, Object>) dirtyData.get("originalItem");
							Object value = originalItem.get(columnName);
							if(value!=null){
								pstmt.setObject(index,value);
							}else{
								index--;
							}
						}
						index++;
					}
					pstmt.addBatch();
					
				}
				pstmt.executeBatch();
			}
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			if(conn!=null){
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			throw new Exception(e.getMessage()); 
		} finally {
			new DataBaseManager().closePstmt(pstmt);
			new DataBaseManager().closeConnection(conn);
		}
		
		return 1;
	}

	public int saveDataFromTableName(Map<String, Object> requestData) throws Exception {
		List<Map<String,Object>> insertDatas = (List<Map<String,Object>>) requestData.get("insertRows");
		List<Map<String,Object>> deleteDatas = (List<Map<String,Object>>) requestData.get("deleteRows");
		List<String> columnNames = (List<String>) requestData.get("columnName");
		String tableName = (String) requestData.get("tableName");
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = new DataBaseManager().getConnection();
			conn.setAutoCommit(false);
			String sql = null;
			//delete
			if(deleteDatas.size()>0){
				for(int i=0;i<deleteDatas.size();i++){
					sql = "delete from "+tableName+" where 1=1 ";					
					for(int j=0;j<columnNames.size();j++){
						String columnName = columnNames.get(j);
						Map<String,Object> originalItem = (Map<String, Object>) deleteDatas.get(i).get("originalItem");
						Object value = originalItem.get(columnName);
						if(value==null){
							sql = sql+ " and "+columnName+" is null";
						}else{
							sql = sql+ " and "+columnName+"=?";
						}
					}
					
					pstmt = conn.prepareStatement(sql);
					Map<String,Object> deleteData = deleteDatas.get(i);
					int index = 1;
					for(int j=0;j<columnNames.size();j++){
						String columnName = columnNames.get(j);
						Map<String,Object> item = (Map<String, Object>) deleteData.get("originalItem");
						Object value = item.get(columnName);
						if(value!=null){
							pstmt.setObject(index,value);
						}else{
							index--;
						}
						index++;
					}
					pstmt.executeUpdate();
				}
				
			}
			sql = "insert into "+tableName+" values(";
			for(int i=0;i<columnNames.size();i++){
				sql = sql +"?,";
			}
			sql = sql.substring(0, sql.lastIndexOf(','));
			sql = sql + ")";
			pstmt = conn.prepareStatement(sql);
			//insert
			if(insertDatas.size()>0){
				for(int i=0;i<insertDatas.size();i++){
					
					Map<String,Object> insertData = insertDatas.get(i);
					for(int j=0;j<columnNames.size();j++){
						String columnName = columnNames.get(j);
						Map<String,Object> item = (Map<String, Object>) insertData.get("item");
						Object value = item.get(columnName);
						pstmt.setObject(j+1,value);
					}
					pstmt.addBatch();
				}
				pstmt.executeBatch();
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(SQLException e) {
			if(conn!=null){
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			throw new Exception(e.getMessage()); 
		} finally {
			new DataBaseManager().closePstmt(pstmt);
			new DataBaseManager().closeConnection(conn);
		}
			
		return 1;
	}
	
	public static void main(String[] args) throws Exception {
		String sql = "select table_name from information_schema.tables where table_schema='spreadjs' and table_type='base table'";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = new DataBaseManager().getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				String table_name = rs.getString("table_name");
				System.out.println("table_name:"+table_name);
			}
			
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			new DataBaseManager().closeConnection(conn);
			new DataBaseManager().closePstmt(pstmt);
		}
		
	}
	
}
	